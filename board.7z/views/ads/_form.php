<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\Ads */
/* @var $form yii\widgets\ActiveForm */

 $now = new DateTime();
 $now = $now->format('Y-m-d H:i:s');

if ($create) {
    $model->date = $now;

}

?>

<div class="ads-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'adname')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'adtext')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'adcount')->textInput() ?>

    <?= $form->field($model, 'userid')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'sum')->textInput() ?>

    <?= $form->field($model,'date')->label() ?>

    </div>

   <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
